package vahalto1_sem;

import cz.cvut.fit.zum.util.Pair;
import java.util.ArrayList;
import java.util.List;

import cz.cvut.fit.zum.api.ga.AbstractEvolution;
import cz.cvut.fit.zum.api.ga.AbstractIndividual;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Random;
import org.openide.util.Exceptions;
import org.openide.util.lookup.ServiceProvider;

/**
 * @author vahalto1
 */
@ServiceProvider(service = AbstractEvolution.class)
public class Evolution extends AbstractEvolution<Individual> implements Runnable {

    Writer writer;
    /**
     * start and final average fitness
     */
    private Pair<Double, Double> avgFitness;
    /**
     * start and final best fitness in whole population
     */
    private Pair<Double, Double> bestFitness;
    /**
     * start and final time
     */
    private Pair<Long, Long> time;
    /**
     * How often to print status of evolution
     */
    private int debugLimit = 10;
    private Random rand = new Random();
    
    /**
     * The population to be used in the evolution
     */
    Population population;

    public Evolution() {
        isFinished = false;
        avgFitness = new Pair<Double, Double>();
        bestFitness = new Pair<Double, Double>();
        time = new Pair<Long, Long>();   
        try {
            writer = new FileWriter("fitness.txt");
        } catch (IOException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

    @Override
    public String getName() {
        return "My evolution";
    }

    @Override
    public void run() {
       
        // Initialize the population
        population = new Population(this, populationSize);
        Random random = new Random();
        
        // Collect initial system time, average fitness, and the best fitness
        time.a = System.currentTimeMillis();
        avgFitness.a = population.getAvgFitness();
        AbstractIndividual best = population.getBestIndividual();
        
        bestFitness.a = best.getFitness();        

        // Show on map
        updateMap(best);
        
       
        
        double oldFitness = 0;
        
        int counter = 0;
        double tempMax = 500;
        double temperature = tempMax;
        
        // Run evolution cycle for the number of generations set in GUI
        for(int g=0; g < generations; g++) {
 
            // the evolution may be terminate from the outside using GUI button
            if (isFinished) {
                
                break;
            }
            
            // initialize the next generation's population
            ArrayList<AbstractIndividual> newInds = new ArrayList<AbstractIndividual>();
            
            // elitism: Preserve the best individual
            // (this is quite exploatory and may lead to premature convergence!)
            Individual individual = (Individual)population.getBestIndividual().deepCopy();
            newInds.add(population.getBestIndividual().deepCopy());
            
            

            
            // keep filling the new population while not enough individuals in there
            List<AbstractIndividual> parents = population.selectIndividuals(populationSize/3);
            while(newInds.size() < populationSize) {
                
               Pair<AbstractIndividual,AbstractIndividual> offspring;
                
                // with some probability, perform crossover
               
                int x = (int)(Math.random() * (populationSize / 3));
                int y = (int)(Math.random() * (populationSize / 3));
                if(crossoverProbability < random.nextDouble()) {
                    offspring = parents.get(x).deepCopy().crossover(
                                    parents.get(y).deepCopy());
                }
                // otherwise, only copy the parents
                else {
                    offspring = new Pair<AbstractIndividual, AbstractIndividual>();
                    offspring.a = parents.get(0).deepCopy();
                    offspring.b = parents.get(1).deepCopy();
                }
                
                // mutate first offspring, add it to the new population
                offspring.a.mutate(mutationProbability);
                offspring.a.computeFitness();
                Individual ind = (Individual)offspring.a;
                newInds.add(ind.getBestNeighbour(temperature));//LOKALNI PROHLEDANI ZDE
                          
                
                // if there is still space left in the new population, add also
                // the second offspring
                if(newInds.size() < populationSize) {
                    offspring.b.mutate(mutationProbability);
                    offspring.b.computeFitness();
                    ind = (Individual)offspring.b;
                    newInds.add(ind.getBestNeighbour(temperature));//LOKALNI PROHLEDANI ZDE
       
                }
            }
           
            
            // replace the current population with the new one
            for(int i=0; i<newInds.size(); i++) {
                population.setIndividualAt(i, newInds.get(i));
            }

            // print statistic
            System.out.println("gen: " + g + "\t bestFit: " + population.getBestIndividual().getFitness() + "\t avgFit: " + population.getAvgFitness());
            try {
                writer.write(((Integer)(int) population.getBestIndividual().getFitness()).toString() + "\n");
                writer.flush();
            } catch (IOException ex) {
                Exceptions.printStackTrace(ex);
            }
            System.out.println("temperature: " + temperature);
            // for very long evolutions print best individual each 1000 generations
            //KATASTROFA...            
            double newBest = population.getBestIndividual().getFitness();
            //System.out.println(population.size());
            if(oldFitness >= newBest){
               
                counter ++;
                if(counter == 50){
                    population.catastrophy();
                    counter = 0;                    
                }
            }
            else{
               // System.out.println("bla");
                
                counter = 0;
            }
            oldFitness = newBest;

            if (g % debugLimit == 0) {
                best = population.getBestIndividual();
                updateMap(best);
            }
            updateGenerationNumber(g);
            temperature = tempMax * (((double)(generations - g)) / generations);
        }

        // === END ===
        time.b = System.currentTimeMillis();
        population.sortByFitness();
        avgFitness.b = population.getAvgFitness();
        best = population.getBestIndividual();
        bestFitness.b = best.getFitness();
        updateMap(best);
        System.out.println("Evolution has finished after " + ((time.b - time.a) / 1000.0) + " s...");
        System.out.println("avgFit(G:0)= " + avgFitness.a + " avgFit(G:" + (generations - 1) + ")= " + avgFitness.b + " -> " + ((avgFitness.b / avgFitness.a) * 100) + " %");
        System.out.println("bstFit(G:0)= " + bestFitness.a + " bstFit(G:" + (generations - 1) + ")= " + bestFitness.b + " -> " + ((bestFitness.b / bestFitness.a) * 100) + " %");
        System.out.println("bestIndividual= " + population.getBestIndividual());
       
        try {
            writer.flush();
            //System.out.println(pop);
        } catch (IOException ex) {
            Exceptions.printStackTrace(ex);
        }

        isFinished = true;
        System.out.println("========== Evolution finished =============");
    }
}
