package vahalto1_sem;

import cz.cvut.fit.zum.api.Node;
import cz.cvut.fit.zum.api.ga.AbstractEvolution;
import cz.cvut.fit.zum.api.ga.AbstractIndividual;
import cz.cvut.fit.zum.data.Edge;
import cz.cvut.fit.zum.data.StateSpace;
import cz.cvut.fit.zum.util.Pair;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;


/**
 * @author vahalto1
 */
public class Individual extends AbstractIndividual {

    private double fitness = Double.NaN;
    private AbstractEvolution evolution;
    public int [] sureThings;
    private boolean prepared = false;
    
    // @TODO Declare your genotype
    private int nodeCount;
    private int []  genotype;
   // private Set<Integer> nodesSelected;
    private int nodesSelected;

    /**
     * Creates a new individual
     * 
     * @param evolution The evolution object
     * @param randomInit <code>true</code> if the individial should be
     * initialized randomly (we do wish to initialize if we copy the individual)
     */
    public Individual(AbstractEvolution evolution, boolean randomInit) {
        
        this.evolution = evolution;
        nodeCount = StateSpace.nodesCount();
        genotype = new int[nodeCount];
        sureThings = new int[nodeCount];
       
        
        
        //nodesSelected = new HashSet<>();
        nodesSelected = 0;
        if(randomInit) {
            prepareProblem();
            // @TODO initialize individual
            for (int i = 0; i < nodeCount; i++) {
                if(sureThings[i] != -1){
                    genotype[i] = sureThings[i];
                }else{
                int bla = ((int)(Math.random() *100)) % 2;
                    
                genotype[i] = bla;
                }
                if(genotype[i] == 1) nodesSelected++; 
                
                 
                
            }
            
            Individual best = getBestNeighbour(nodeCount/100);
            setGens(best.nodeCount, best.genotype, best.nodesSelected, best.sureThings);  
        }
         
    }

    @Override
    public boolean isNodeSelected(int j) {
        
        
        // @TODO Implement based on your individual's genotype
        if(genotype[j] == 1) return true;
        else return false;
    }

    private void prepareProblem(){
        
        for (int i = 0; i < nodeCount; i++) {
                sureThings[i] = -1;
        }
       
        List<Node> nodes = StateSpace.getNodes();      
        
    //    HashSet<Node> solvedNodes = new HashSet<>();
        HashSet<Edge> solvedEdges = new HashSet<>();
        Queue<Node> leaves = new LinkedList<>();
        
         for (Node n : nodes) { 
              if(n.getEdges().size() == 1){                    
                    leaves.add(n);                                        
                  
                }     
         }
         //int x = 0;
        while(!leaves.isEmpty()){
            //System.out.println(x);
           Node n = leaves.poll();
           Node neighbour;
           Edge notSolvedEdge = new Edge();
          for(Edge e: n.getEdges()){
              if(!solvedEdges.contains(e)){
                  notSolvedEdge =e;
              }
          }
           if(notSolvedEdge.getFromId() == n.getId()) neighbour = nodes.get(notSolvedEdge.getToId());
           else neighbour = nodes.get(notSolvedEdge.getFromId());
           
           sureThings[n.getId()] = 0;
           sureThings[neighbour.getId()] = 1;
        
           
           for(Edge e : neighbour.getEdges()){
               solvedEdges.add(e);
               Node nn;
               int bla = 0;
               if(e.getFromId() == neighbour.getId()) nn = nodes.get(e.getToId());
               else nn = nodes.get(e.getFromId());
               for(Edge ee : nn.getEdges()){
                   if(!solvedEdges.contains(ee)) bla++;
               }
               if(bla == 1) leaves.add(nn);
           } 
          
        }
        prepared = true;
       
    }
    
    
    /**
     * Evaluate the value of the fitness function for the individual. After
     * the fitness is computed, the <code>getFitness</code> may be called
     * repeatedly, saving computation time.
     */
    @Override
    public void computeFitness() {
        
        
        
        // @TODO: Implement fitness based on your implementation
        // Hint: use the StateSpace object
        
       
            repair();    
            
        
            fitness = (nodeCount - nodesSelected);
        
    }

    /**
     * Only return the computed fitness value
     *
     * @return value of fitness fucntion
     */
    @Override
    public double getFitness() {
        return this.fitness;
    }

    /**
     * Does random changes in the individual's genotype, taking mutation
     * probability into account.
     * 
     * @param mutationRate Probability of a bit being inverted, i.e. a node
     * being added to/removed from the vertex cover.
     */
    @Override
    public void mutate(double mutationRate) {
        // TODO: Implement mutation of the genotype
        
        
        for(int i = 0; i < nodeCount; i++){
            if(sureThings[i] != -1) continue;
            //will we mutate?
            if(Math.random() < mutationRate){
                swapBit(i);
            }
        }
        
    }
    private void swapBit(int i){
        if(genotype[i] == 1){
            genotype[i] = 0;
            nodesSelected--;
        }
        else{
            genotype[i] = 1;
            nodesSelected++;
        }
    }
    /**
     * Crosses the current individual over with other individual given as a
     * parameter, yielding a pair of offsprings.
     * 
     * @param other The other individual to be crossed over with
     * @return A couple of offspring individuals
     */
    @Override
    public Pair crossover(AbstractIndividual other) {

        Pair<Individual,Individual> result = new Pair();

        // @TODO implement your own crossover
        //zkopiruju
        Individual o = (Individual) other;
        Individual new1 = this.deepCopy();
        Individual new2 = o.deepCopy();
        
        //vypocitam crosspoint
        int cross =(int)Math.random()*nodeCount;   
        
        for(int i = 0; i < nodeCount; i++){
            //prvni cast
            if(i < cross){
               new1.genotype[i] = this.genotype[i];
               new2.genotype[i] = o.genotype[i];
            }   
            //druha cast
            else{
               new1.genotype[i] = o.genotype[i];
               new2.genotype[i] = this.genotype[i];
            }
        } 
        new1.updateNodes();
        new2.updateNodes();
        result.a = new1;
        result.b = new2;
        
        return result;
    }

    
    /**
     * When you are changing an individual (eg. at crossover) you probably don't
     * want to affect the old one (you don't want to destruct it). So you have
     * to implement "deep copy" of this object.
     *
     * @return identical individual
     */
    @Override
    public Individual deepCopy() {
        Individual newOne = new Individual(evolution, false);
        int [] newGens = new int[nodeCount];
        int [] newSure = new int[nodeCount];
        int newNodesSelected = 0;
        
        for(int i = 0; i < nodeCount; i++){
            if(genotype[i] == 0) newGens[i] = 0;
            else{
                newGens[i] = 1;
                newNodesSelected++;
            }
            newSure[i] = sureThings[i];
        }
        newOne.setGens(this.nodeCount, newGens, newNodesSelected, newSure);
      

        newOne.fitness = this.fitness;
        return newOne;
    }

    /**
     * Return a string representation of the individual.
     *
     * @return The string representing this object.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        
        /* TODO: implement own string representation, such as a comma-separated
         * list of indices of nodes in the vertex cover
         */
        String res = "";
        res = res.concat("[");
      //  System.out.println(nodeCount);
        for (int i = 0; i < nodeCount - 2; i++) {
            res = res.concat(genotype[i] + ",");
        //    System.out.println("bla");
        }
        res = res.concat(genotype[nodeCount - 1] + "]");
       // sb.append(super.toString());

        //return sb.toString();
        return res;
    }
    private void repair(){
       for(Edge e : StateSpace.getEdges()){
           //vrcholy u hrany
           if(genotype[e.getFromId()] == 0 && genotype[e.getToId()] == 0){
               int n1 = e.getFromId();
               int n2 = e.getToId();
               //jejich stupne
               int s1 = StateSpace.getNode(n1).getEdges().size();
               int s2 = StateSpace.getNode(n2).getEdges().size();
               //pridam ten s vyssim stupnem
               if(s1 > s2){
                   genotype[n1] = 1;
                   //nodesSelected.add(n1);
               }
               else {
                   genotype[n2] = 1;
                   //nodesSelected.add(n2);
               }
               nodesSelected ++;
           }
                
    
       }
    }
    public void setGens(int nc, int [] g, int ns, int [] sure){
        genotype = g;
        sureThings = sure;
        nodeCount = nc;
        nodesSelected = ns;
        computeFitness();
        
    }
    void updateNodes(){
        nodesSelected = 0;
        for(int i = 0; i < nodeCount; i++){
            if(genotype[i] == 1){
                nodesSelected++;
            }
        }
    }
    public int[] getGenotype(){
        return genotype;
    }
    public Individual getBestNeighbour(double t){
            Individual neighbour = this.deepCopy();          
                           
              for(int j = 0; j < t; j++){
                neighbour.mutate(2);
                neighbour.computeFitness();
                 if(neighbour.getFitness() > this.getFitness()) break;
              }
                                  
            
           
            //is he best?
            if(neighbour.getFitness() >= this.getFitness()){
                return neighbour;
            }
            //annealing
            else if(Math.pow(Math.E, (neighbour.getFitness() - this.getFitness()) / t) > Math.random()){
                return neighbour;
            }
            
        return this;        
        
    }
}
