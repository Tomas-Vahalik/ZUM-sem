package vahalto1_sem;

import cz.cvut.fit.zum.api.ga.AbstractEvolution;
import cz.cvut.fit.zum.api.ga.AbstractIndividual;
import cz.cvut.fit.zum.api.ga.AbstractPopulation;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author vahalto1
 */
public class Population extends AbstractPopulation {
    private AbstractEvolution evolution;
    public Population(AbstractEvolution evolution, int size) {
        individuals = new Individual[size];
        this.evolution = evolution;
        for (int i = 0; i < individuals.length; i++) {
            individuals[i] = new Individual(evolution, true);
            individuals[i].computeFitness();
        }
       
    }

    /**
     * Method to select individuals from population
     *
     * @param count The number of individuals to be selected
     * @return List of selected individuals
     */
    public List<AbstractIndividual> selectIndividuals(int count) {
       
        
        return tournament(count);
    }
    public List<AbstractIndividual> roulette (int count){
        ArrayList<AbstractIndividual> selected = new ArrayList<AbstractIndividual>();
        double totalFitness = 0;
        for (AbstractIndividual individual : this.individuals) {
            totalFitness += individual.getFitness();
        }
        while(selected.size() != count){
            for (AbstractIndividual individual : this.individuals) {

                double prob = individual.getFitness() / totalFitness;
                if (Math.random() < prob && !selected.contains(individual)) {
                    selected.add(individual);
                    if(selected.size() == count) break;
                }
            }
        }
        
        return selected;
    }
    public List<AbstractIndividual> tournament (int count){
       
        ArrayList<AbstractIndividual> selected = new ArrayList<AbstractIndividual>();
        Set<AbstractIndividual> candidates = new HashSet<AbstractIndividual>();
       
       int k = 30;
        for(int i = 0; i < count; i++){
            double best = 0;
            AbstractIndividual ind = this.individuals[0];
            //choose K candidates
            for(int j = 0; j < k; j++){
                int index = 0;
                do{
                 index = (int)(Math.random() * this.size());
                    
                }while(candidates.contains(this.individuals[index]));
                candidates.add(this.individuals[index]);
            }
            //pick best one
            for (AbstractIndividual candidate : candidates) {
                if(candidate.getFitness() > best){
                    best = candidate.getFitness();
                    ind = candidate;
                }
            }
                
            
            selected.add(ind);
            candidates.clear();
        }
        return selected;
    }
    public void catastrophy(){
        System.out.println("BOOOOOOOM");
        Comparator<AbstractIndividual> comparator = new Comparator<AbstractIndividual>() {
            @Override
            public int compare(AbstractIndividual left, AbstractIndividual right) {
                return (int) (right.getFitness() - left.getFitness());
            }
        };
        //only 1/50 best individuals will survive  
        Arrays.sort(individuals, comparator);
        for(int i = (int)individuals.length/50; i < individuals.length; i++){
            individuals[i] = new Individual(evolution, true);
        }
       
       
       
    }
}
